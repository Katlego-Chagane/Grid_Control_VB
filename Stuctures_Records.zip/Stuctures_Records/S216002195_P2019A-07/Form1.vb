﻿' *********************************************************************************
' Surname, Initials: Chagane, K
' Student Number: 216002195
' Practical: P2019A-07
' Class name: IFM
' *********************************************************************************
Option Explicit On
Option Strict On



Public Class IFM

    Private Sub SetG(ByVal a As Integer, ByVal b As Integer, ByVal c As String)
        grdA.Col = a
        grdA.Row = b
        grdA.Text = c
    End Sub

    'defining the structure record
    Private Structure Agent


        Public CodeName, Rating, Country, Password As String
        Public AverageCost As Double
        Public Operations() As Integer 'number of operations
        Public OperationCost, ExpensiveOperation, TotalCost As Integer

    End Structure

    Private Agents() As Agent ' nAgents/that n Agent,nthAgent
    Private nAgents, nOperations As Integer ' number of agents & operations













    Private Sub InputsToDisplay()
        For a = 1 To nAgents

            Agents(a).CodeName = InputBox("What is the Code Name of Agent " & CStr(a) & "?")

            For b = 1 To nOperations
                Agents(a).Password = InputBox("What is the Password of Agent " & CStr(a) & " in operation " & CStr(b) & "?")

            Next b
        Next a
    End Sub
    Private Sub btnInput_Click(sender As Object, e As EventArgs) Handles btnInput.Click

        Init()
        InputsToDisplay()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    'calculates operations totals
    Private Sub TotalOperations()

        For f = 1 To nAgents
            Agents(f).TotalCost = 0
            For a = 1 To nOperations
                'Agents(f).TotalCost += Agents(f).Operations(a).OperationCost
                Agents(f).TotalCost += Agents(f).OperationCost
            Next a
            SetG(f, nOperations + 1, CStr(Agents(f).TotalCost))
        Next f

    End Sub
    'Initialises the Grid with nAgents & nOperations
    Private Sub Init()
        nAgents = CInt(txtAgents.Text)
        nOperations = CInt(txtOperations.Text)

        ReDim Agents(nAgents)
        For a = 1 To nAgents
            ReDim Agents(a).Operations(nOperations)

        Next a

        grdA.Rows = nAgents + 1
        grdA.Cols = nOperations + 2

        For b = 1 To nAgents
            SetG(b, 0, "Agent " & CStr(b))
        Next b

        For c = 1 To nOperations
            SetG(0, c, "Operation " & CStr(c))
        Next c

        SetG(0, nOperations + 1, "Totals ")
    End Sub

    Private Sub MostExpensive()
        Dim exp As Double
        Dim idex As Integer
        exp = Agents(1).TotalCost
        idex = 1
        For f = 2 To nAgents
            If exp < Agents(f).TotalCost Then
                exp = Agents(f).TotalCost
                idex = f
            End If
        Next f
        'Display Calculated Cost >
        Dim R As Integer '
        Dim RatingA, RatingB As String
        R = idex Mod 2


        If R = 1 Then
            RatingA = "The Agent is rated A"
        Else
            RatingB = "The Agent is rated B"
        End If

        MsgBox(Agents(idex).TotalCost & R)


    End Sub

    'Left with the place values on the grid, the method could be applied in InputsToDisplay()


End Class
